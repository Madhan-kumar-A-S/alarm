package com.better.alarm.domain;

import java.util.Calendar;

/** Created by Yuriy on 29.06.2017. */
public interface Calendars {
  Calendar now();
}
